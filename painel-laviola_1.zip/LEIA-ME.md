# Painel de Vendas · Laviola Phones

Site para a equipe acompanhar as vendas ao vivo, com os dados do Mercado Phone.

- **`/`**: painel da equipe (link aberto, sem login). Mostra faturamento, vendas, aparelhos, ticket médio, ranking, gráfico do mês, últimas vendas e mais vendidos. Filtra por hoje, semana ou mês e por loja.
- **`/dono.html`**: área do dono, com senha. Mostra lucro bruto, margem, custo e lucro líquido (DRE) de hoje e do mês, por loja.

## Por que o lucro fica protegido

A chave do Mercado Phone fica só no servidor (Vercel), nunca no celular de ninguém.
O endereço da equipe (`/api/painel`) devolve só números agregados de venda: **nada de custo, lucro, CPF, telefone ou nome de cliente**.
O lucro só sai pelo `/api/dono`, que exige a senha. Mesmo alguém que abra o código da página não encontra o lucro, porque ele nunca é enviado.

---

## Como colocar no ar (uns 20 minutos, grátis)

### 1. Pegue o acesso ao Mercado Phone
O site usa o mesmo conector que o Claude usa para ler o seu Mercado Phone. Você vai precisar de:
- **A URL do conector (servidor MCP)**: aparece no Claude em *Configurações → Conectores*, no conector do Mercado Phone / Laviola Phones. Se não aparecer, peça ao **suporte do Mercado Phone** a "URL do servidor MCP e a chave de API" da sua conta.
- **A chave de API**: às vezes ela já vem dentro da URL. Se vier separada, guarde para o passo 3.

> Trate essa URL e essa chave como senha do banco: elas dão acesso a tudo do sistema.

### 2. Suba o código
1. Crie uma conta grátis em **github.com** e outra em **vercel.com** (entre com o GitHub).
2. No GitHub, crie um repositório **privado** chamado `painel-laviola` e envie todos os arquivos desta pasta (dá para arrastar os arquivos no navegador: *Add file → Upload files*).
3. Na Vercel, clique em **Add New → Project**, escolha o repositório `painel-laviola` e clique em **Deploy**. Pode deixar todas as opções como estão.

### 3. Configure as variáveis (Vercel → Project → Settings → Environment Variables)

| Variável | O que colocar | Obrigatória |
|---|---|---|
| `MERCADOPHONE_MCP_URL` | URL do conector do passo 1 | Sim |
| `MERCADOPHONE_TOKEN` | Chave de API, se ela **não** vier na URL | Só se precisar |
| `SENHA_DONO` | Uma senha forte, só sua, para a área do dono | Sim |
| `METAS` | Metas do mês (veja abaixo) | Não |
| `OCULTAR_DO_RANKING` | Nomes que não aparecem no ranking, separados por vírgula | Não |

Depois de salvar, vá em **Deployments → ⋯ → Redeploy** para valer.

### 4. Mande para a equipe
O link fica tipo `https://painel-laviola.vercel.app`. No celular, abra no navegador e use **Adicionar à tela de início**: vira um "app" com ícone.
A área do dono é o mesmo link com `/dono.html` no final. Não mande esse para ninguém.

---

## Ajustes

**Metas** (aparecem como barra de progresso no mês). Exemplo do valor da variável `METAS`:
```json
{"loja":{"5107":90000,"5108":45000},"vendedor":{"ANA JÚLIA DE SOUZA INÁCIO":60000,"ANDREWS MEIRELLES CORREIA":25000}}
```
`5107` = Carangola, `5108` = Espera Feliz. O nome do vendedor tem que ser igual ao do Mercado Phone.

**Ranking**: por padrão, "Padrão", Higor e Bruna **contam no total da loja** mas **não aparecem no ranking**, para o ranking ser só da equipe. Para mudar, preencha `OCULTAR_DO_RANKING`. Exemplo para mostrar vocês dois: `Padrão`.

**Quão "ao vivo"**: a tela atualiza sozinha a cada 1 minuto. O servidor guarda a resposta por 60 segundos (`CACHE_SEGUNDOS`) para não sobrecarregar o Mercado Phone.

**Aparelho x acessório**: um item conta como aparelho quando o nome tem a memória (ex.: `128GB`). Serviços (transferência, limpeza, impressão, renovação...) não entram em acessórios. A regra fica em `lib/agregar.js`.

## Arquivos
```
index.html          painel da equipe
dono.html           área do dono (senha)
api/painel.js       dados da equipe (sem lucro)
api/dono.js         DRE e lucro (exige senha)
lib/mercadophone.js conexão com o Mercado Phone
lib/agregar.js      cálculos do ranking e totais
lib/config.js       lojas, metas, quem fica fora do ranking
```
