import { resumoEquipe } from '../lib/dados.js';

// Público: é o que os vendedores abrem no celular.
export default async function handler(req, res) {
  try {
    const dados = await resumoEquipe();
    res.setHeader('Cache-Control', 's-maxage=60, stale-while-revalidate=120');
    res.status(200).json(dados);
  } catch (e) {
    console.error(e);
    res.status(502).json({ erro: 'Não consegui buscar as vendas agora. Tente de novo em instantes.' });
  }
}
