import { timingSafeEqual } from 'node:crypto';
import { resumoDono } from '../lib/dados.js';

function senhaConfere(enviada) {
  const certa = process.env.SENHA_DONO || '';
  if (!certa || !enviada) return false;
  const a = Buffer.from(String(enviada));
  const b = Buffer.from(certa);
  return a.length === b.length && timingSafeEqual(a, b);
}

// Só responde com a senha certa. O lucro nunca passa pelo /api/painel.
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (!senhaConfere(req.headers['x-senha'])) {
    await new Promise((ok) => setTimeout(ok, 800)); // atrasa quem tenta adivinhar
    return res.status(401).json({ erro: 'Senha incorreta' });
  }
  try {
    res.status(200).json(await resumoDono());
  } catch (e) {
    console.error(e);
    res.status(502).json({ erro: 'Não consegui buscar o DRE agora.' });
  }
}
